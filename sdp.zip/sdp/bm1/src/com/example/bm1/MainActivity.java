package com.example.bm1;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;

@SuppressLint("NewApi") public class MainActivity extends Activity {
	EditText editText1;
    EditText editText2;
    TextView textView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1 = (EditText) findViewById(R.id.editText1);
            editText2 = (EditText) findViewById(R.id.editText2);
            textView3 = (TextView) findViewById(R.id.textView3);

            Button button1 = (Button) findViewById(R.id.button1);
            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    calculateBMI();
                }
            });
        }

        @SuppressLint("NewApi") private void calculateBMI() {
            String weightStr = editText1.getText().toString();
            String heightStr = editText2.getText().toString();

            if (!weightStr.isEmpty() && !heightStr.isEmpty()) {
                float weight = Float.parseFloat(weightStr);
                float height = Float.parseFloat(heightStr);

                float bmi = weight / (height * height);

                String result = "Your BMI: " + bmi;
                textView3.setText(result);
            } else {
                textView3.setText("Please enter weight and height.");
            }
        }
    }