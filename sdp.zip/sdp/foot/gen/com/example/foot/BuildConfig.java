/** Automatically generated file. DO NOT MODIFY */
package com.example.foot;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}