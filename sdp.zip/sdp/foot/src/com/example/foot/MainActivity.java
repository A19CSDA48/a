package com.example.foot;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;

@SuppressLint("NewApi") public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editTextInches = (EditText) findViewById(R.id.editTextInches);
        Button btnConvert = (Button) findViewById(R.id.btnConvert);
        final TextView textViewResult = (TextView) findViewById(R.id.textViewResult);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the input value in inches
                String inchesStr = editTextInches.getText().toString();

                if (!inchesStr.isEmpty()) {
                    // Convert inches to feet
                    double inches = Double.parseDouble(inchesStr);
                    double feet = inches / 12.0;

                    // Display the result
                    textViewResult.setText(String.format("%.2f inches is %.2f feet", inches, feet));
                } else {
                    // Display an error message if the input is empty
                    textViewResult.setText("Please enter inches.");
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
