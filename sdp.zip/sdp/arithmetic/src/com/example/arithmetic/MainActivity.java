package com.example.arithmetic;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;

public class MainActivity extends Activity {
	EditText e1,e2,e3;
	Button b1,b2,b3,b4,b5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        b5=(Button)findViewById(R.id.button5);
        e1=(EditText)findViewById(R.id.editText1);
    	e2=(EditText)findViewById(R.id.editText2);
    	e3=(EditText)findViewById(R.id.editText3);
        
        b1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				int n1=Integer.parseInt(e1.getText().toString());
				int n2=Integer.parseInt(e2.getText().toString());
				int res=n1+n2;
				e3.setText("total="+res);
			}
		});
        
        b2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				int n1=Integer.parseInt(e1.getText().toString());
				int n2=Integer.parseInt(e2.getText().toString());
				int res=n1-n2;
				e3.setText("total="+res);
			}
		});
        
        b3.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				int n1=Integer.parseInt(e1.getText().toString());
				int n2=Integer.parseInt(e2.getText().toString());
				int res=n1*n2;
				e3.setText("total="+res);
				
				
			}
		});
        
        b4.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				int n1=Integer.parseInt(e1.getText().toString());
				int n2=Integer.parseInt(e2.getText().toString());
				int res=n1/n2;
				e3.setText("total="+res);
			}
		});
        
        b5.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				int n1=Integer.parseInt(e1.getText().toString());
				int n2=Integer.parseInt(e2.getText().toString());
				int res=n1%n2;
				e3.setText("total="+res);
			}
		});
        
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
