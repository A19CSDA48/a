package com.example.popupmenu;

import android.os.Build;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;
public class MainActivity extends Activity {
Button bt1;
@SuppressLint("NewApi")
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
bt1=(Button)findViewById(R.id.button1);
bt1.setOnClickListener(new View.OnClickListener() {
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public void onClick(View v) {
// TODO Auto-generated method stub
PopupMenu pop=new PopupMenu(MainActivity.this,v);
pop.getMenuInflater().inflate(R.menu.main, pop.getMenu());
pop.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public boolean onMenuItemClick(MenuItem item ) {
// TODO Auto-generated method stub
Toast.makeText(MainActivity.this,"you click:"+item.getTitle(), 
Toast.LENGTH_LONG).show();
return true;
}
});
pop.show();
}
});
}
@Override
public boolean onCreateOptionsMenu(Menu menu) {
// Inflate the menu; this adds items to the action bar if it is present.
getMenuInflater().inflate(R.menu.main, menu);
return true;
}
}