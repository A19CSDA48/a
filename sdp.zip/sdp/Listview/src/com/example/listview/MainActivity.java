package com.example.listview;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends Activity {
ListView l1;
TextView t1;
String[] festivals={"Diwali","Ramzon","Christmas","pongal","Bakrid","Easter"};
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
l1=(ListView)findViewById(R.id.listView1);
t1=(TextView)findViewById(R.id.textView1);
final ArrayAdapter adapter=new 
ArrayAdapter(this,R.layout.activity_main,R.id.textView1,festivals);
l1.setAdapter(adapter);
l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
@Override
public void onItemClick(AdapterView<?> arg0, View arg1, int position,
long arg3) {
// TODO Auto-generated method stub
String Value="Happy"+adapter.getItem(position);
Toast.makeText(getApplicationContext(),Value,Toast.LENGTH_LONG).show();
}
});
}
@Override
public boolean onCreateOptionsMenu(Menu menu) {
// Inflate the menu; this adds items to the action bar if it is present.
getMenuInflater().inflate(R.menu.main, menu);
return true;
}
}
