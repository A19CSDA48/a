package com.example.celsius;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;


public class MainActivity extends Activity {
	EditText num;
    TextView result;
    double c,f;
    TableLayout tab;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num=(EditText)findViewById(R.id.txtNumber);
        result=(TextView)findViewById(R.id.txtResult);
        tab=(TableLayout)findViewById(R.id.tab1);
      
    }
        public void ConverToFahrenheit(View v)
        {
            c=Double.parseDouble(String.valueOf(num.getText()));
            String res=String.valueOf((c*9)/5+32);
            result.setText(res);
        }
        public void ConverToCelsius(View v)
        {
            f=Double.parseDouble(String.valueOf(num.getText()));
            String res=String.valueOf((f-32)*5/9);
            result.setText(res);
        }
        }
