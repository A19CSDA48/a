/** Automatically generated file. DO NOT MODIFY */
package com.example.odd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}