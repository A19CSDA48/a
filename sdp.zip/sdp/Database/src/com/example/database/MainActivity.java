package com.example.database;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.Menu;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
	EditText Rollno,Name,Marks;
    Button Insert,Delete,Update,View,ViewAll;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Rollno=(EditText)findViewById(R.id.editText1);
        Name=(EditText)findViewById(R.id.editText2);
        Marks=(EditText)findViewById(R.id.editText3);
        Insert=(Button)findViewById(R.id.button1);
        Delete=(Button)findViewById(R.id.button2);
        Update=(Button)findViewById(R.id.button3);
        View=(Button)findViewById(R.id.button4);
        ViewAll=(Button)findViewById(R.id.button5);
        
        db = openOrCreateDatabase("StudentDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(rollno VARCHAR,name VARCHAR,marks VARCHAR);");

        Insert.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi") @Override
            public void onClick(View v) {
                try {
                    String rollNo = Rollno.getText().toString().trim();
                    String name = Name.getText().toString().trim();
                    String marks = Marks.getText().toString().trim();

                    if (rollNo.isEmpty() || name.isEmpty() || marks.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please fill in all fields", Toast.LENGTH_LONG).show();
                    } else {
                        db.execSQL("INSERT INTO student VALUES('" + rollNo + "','" + name + "','" + marks + "');");
                        Toast.makeText(getApplicationContext(), "Data inserted successfully", Toast.LENGTH_LONG).show();
                        clearText();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });       
        Delete.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi") @Override
            public void onClick(View v) {
                try {
                    String rollNo = Rollno.getText().toString().trim();
                    if (rollNo.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please enter a Roll No to delete", Toast.LENGTH_LONG).show();
                    } else {
                        db.execSQL("DELETE FROM student WHERE rollno = '" + rollNo + "'");
                        Toast.makeText(getApplicationContext(), "Record deleted successfully", Toast.LENGTH_LONG).show();
                        clearText();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Update.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi") @Override
            public void onClick(View v) {
                try {
                    String rollNo = Rollno.getText().toString().trim();
                    String name = Name.getText().toString().trim();
                    String marks = Marks.getText().toString().trim();

                    if (rollNo.isEmpty() || name.isEmpty() || marks.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please fill in all fields", Toast.LENGTH_LONG).show();
                    } else {
                        db.execSQL("UPDATE student SET name = '" + name + "', marks = '" + marks + "' WHERE rollno = '" + rollNo + "'");
                        Toast.makeText(getApplicationContext(), "Record updated successfully", Toast.LENGTH_LONG).show();
                         clearText();
                        
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        View.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi") @Override
            public void onClick(View v) {
                try {
                    String rollNo = Rollno.getText().toString().trim();
                    if (rollNo.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please enter a Roll No to view", Toast.LENGTH_LONG).show();
                    } else {
                        Cursor c = db.rawQuery("SELECT * FROM student WHERE rollno = '" + rollNo + "'", null);
                        if (c.moveToFirst()) {
                            String name = c.getString(1);
                            String marks = c.getString(2);
                            showMessage("Student Record", "Roll No: " + rollNo + "\nName: " + name + "\nMarks: " + marks);
                            clearText();
                        } else {
                            Toast.makeText(getApplicationContext(), "No record found for Roll No: " + rollNo, Toast.LENGTH_LONG).show();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    ViewAll.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            try {
                Cursor c = db.rawQuery("SELECT * FROM student", null);
                if (c.getCount() == 0) {
                    Toast.makeText(getApplicationContext(), "No records found", Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuilder buffer = new StringBuilder();
                while (c.moveToNext()) {
                    buffer.append("Roll No: " + c.getString(0) + "\n");
                    buffer.append("Name: " + c.getString(1) + "\n");
                    buffer.append("Marks: " + c.getString(2) + "\n\n");
                }
                showMessage("Student Records", buffer.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    });
}
   private void showMessage(String title, String message) {
    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
    builder.setCancelable(true);
    builder.setTitle(title);
    builder.setMessage(message);
    builder.show();
}
   public void clearText()
   {
       Rollno.setText("");
       Name.setText("");
       Marks.setText("");
       Rollno.requestFocus();
   }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
