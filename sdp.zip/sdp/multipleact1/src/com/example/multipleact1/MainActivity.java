package com.example.multipleact1;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TextView; 
import android.view.View; 
import android.widget.Button;
public class MainActivity extends Activity {
TextView textView;
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
textView = (TextView) findViewById(R.id.action_settings);
}
public void Ganesh(View View) 
{ 
String button_text; 
button_text =((Button)View).getText().toString(); 
if(button_text.equals("click second activity")) 
{ 
Intent ganesh = new Intent(this,Second.class); 
startActivity(ganesh); 
} 
else if (button_text.equals("click third activity")) 
{ 
Intent mass = new Intent(this,Third.class); 
startActivity(mass); 
} 
} 
@Override
public boolean onCreateOptionsMenu(Menu menu) {
// Inflate the menu; this adds items to the action bar if it is present.
getMenuInflater().inflate(R.menu.main, menu);
return true;
}
}
