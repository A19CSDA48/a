package com.example.contex;

import android.os.Bundle;
import android.app.Activity;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.Button;
import android.widget.Toast;
public class MainActivity extends Activity {
Button bt1;
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
bt1=(Button)findViewById(R.id.button1);
registerForContextMenu(bt1);
}
public void onCreateContextMenu(ContextMenu menu,View v,ContextMenuInfo mi)
{
super.onCreateContextMenu(menu, v, mi);
menu.setHeaderTitle("ContextMenu");
menu.add(0,v.getId(),0,"help");
menu.add(0,v.getId(),0,"upload");
menu.add(0,v.getId(),0,"del");
menu.add(0,v.getId(),0,"feedback");
}
public boolean onContextItemSelected(MenuItem im)
{
Toast.makeText(getApplicationContext(),"selct"+im.getTitle(),Toast.LENGTH_LONG).show();
return true;
}
@Override
public boolean onCreateOptionsMenu(Menu menu) {
// Inflate the menu; this adds items to the action bar if it is present.
getMenuInflater().inflate(R.menu.main, menu);
return true;
}
}